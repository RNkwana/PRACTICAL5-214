#ifndef DOORS_H
#define DOORS_H

class Doors {

public: 
    void lock();
    void unlock();
};
#endif