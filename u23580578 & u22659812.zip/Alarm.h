#ifndef ALARM_H
#define ALARM_H
#include "Observers.h"

class Alarm : public Observers {

public: 
    void update();
};

#endif