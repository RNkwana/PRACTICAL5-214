#include <iostream>
#include "Alarm.h"

void Alarm::update(){
    std::cout <<"Alarm is activated due to motion detected!" << std::endl;
}