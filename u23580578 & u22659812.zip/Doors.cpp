#include <iostream>
#include "Doors.h"

void Doors::lock(){
    std::cout << "Door is Locked." << std::endl;
}

void Doors::unlock(){
    std::cout << "Door is unlocked." << std::endl;
}